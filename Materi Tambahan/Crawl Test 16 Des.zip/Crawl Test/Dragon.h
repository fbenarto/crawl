#include "Monster.h"

class Dragon : public Monster
{
	protected:

        void createDragon()
        {
            this->name = "Dragon";
            this->spellName = "Fire";
            this->spellCost = 10;
            this->spellDuration = 5;
            this->behavior = true;
            this->description = "A flying monster that breathes fire";
        }
        void monsterName(string name)
        {
            cout << name << endl;
        }
        void monsterSpell(string spellName, int spellCost, int spellDuration, int spellDamage, int spellSuccess)
        {
            cout << "Spell Name: " << spellName << endl;
            cout << "Spell Cost: " << spellCost << endl;
            cout << "The spell lasts for " << spellDuration << " seconds" << endl;
        }
        void monsterBehavior(bool behavior)
        {
            if(behavior)
            {
                cout << "Monster is Aggressive" << endl;
            }
            else
            {
                cout << "Monster is not Aggressive" << endl;
            }
        }
        void monsterDescription(string description)
        {
            cout << description << endl << endl;
        }
		void add()
		{
            createDragon();
            monsterName(name);
            monsterSpell(spellName, spellCost, spellDuration, spellDamage, spellSuccess);
            monsterBehavior(behavior);
            monsterDescription(description);
		}
};

