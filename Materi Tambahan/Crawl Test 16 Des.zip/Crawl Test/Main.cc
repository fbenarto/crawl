#include "Serpent.h"
#include "Dragon.h"
#include "Ghost.h"

class Print : protected Dragon, protected Serpent, protected Ghost
{
    public:
        void create()
        {
            Dragon::add();
            Serpent::add();
            Ghost::add();
        }
};

int main()
{
    Print print;
    print.create();
    return 0;
}
