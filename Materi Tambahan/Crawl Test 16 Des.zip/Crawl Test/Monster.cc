#include "Monster.h"

void Monster::monsterName(string name)
{
    cout << "Monster Name" << endl;
}
void Monster::monsterSpell(string spellName, int spellCost, int spellDuration, int spellDamage, int spellSuccess)
{
    cout << "Spell Name" << endl;
	cout << "Spell Cost" << endl;
}
void Monster::monsterBehavior(bool behavior)
{
	cout << "Monster Behavior" << endl;
}
void Monster::monsterDescription(string description)
{
    cout << "Monster Description" << endl << endl;
}
