#ifndef MONSTER_H
#define MONSTER_H

#include <iostream>
#include <string>

using namespace std;

class Monster
{
	public:
		string name;
		string spellName;
		int spellCost;
		int spellDuration;
		int spellDamage;
		int spellSuccess;
		bool behavior;
		string description;

		virtual void monsterName(string name);
		virtual void monsterSpell(string spellName, int spellCost, int spellDuration, int spellDamage, int spellSuccess);
		virtual void monsterBehavior(bool behavior);
		virtual void monsterDescription(string description);
};
#endif
