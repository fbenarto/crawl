#include "Monster.h"


class Serpent : protected Monster
{
	protected:
		void createSerpent()
        {
            this->name = "Serpent";
            this->spellName = "Poison";
            this->spellCost = 5;
            this->spellSuccess = 85;
            this->behavior = true;
            this->description = "A snake-like monster that spews poison";
        }
        void monsterName(string name)
        {
            cout << name << endl;
        }
        void monsterSpell(string spellName, int spellCost, int spellDuration, int spellDamage, int spellSuccess)
        {
            cout << "Spell Name: " << spellName << endl;
            cout << "Spell Cost: " << spellCost << endl;
            cout << "The spell succeeds " << spellSuccess << "% of the time" << endl;
        }
        void monsterBehavior(bool behavior)
        {
            if(behavior)
            {
                cout << "Monster is Aggressive" << endl;
            }
            else
            {
                cout << "Monster is not Aggressive" << endl;
            }
        }
        void monsterDescription(string description)
        {
            cout << description << endl << endl;
        }
		void add()
		{
            createSerpent();
            monsterName(name);
            monsterSpell(spellName, spellCost, spellDuration, spellDamage, spellSuccess);
            monsterBehavior(behavior);
            monsterDescription(description);
		}
};

