#ifndef BEHAVIOR_H
#define BEHAVIOR_H

#include <iostream>
#include <string>
using namespace std;

class Behavior
{
	protected:
		bool canAttack;
};
#endif