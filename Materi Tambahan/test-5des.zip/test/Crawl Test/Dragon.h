#include "Monster.h"


class Dragon : protected Monster
{
	protected:
		void add()
		{
			Monster::newMonster("Dragon");
			Monster::createSpell("Fire",10);
			Monster::addBehavior(true);
			Monster::addText("A flying monster that breathes fire");
		}
};
