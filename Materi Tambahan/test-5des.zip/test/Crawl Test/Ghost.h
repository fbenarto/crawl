#include "Monster.h"


class Ghost : protected Monster
{
	protected:
		void add()
		{
			Monster::newMonster("Ghost");
			Monster::createSpell("Curse",20);
			Monster::addBehavior(true);
			Monster::addText("An astral creature wandering around");
		}
};
