#ifndef MONSTER_H
#define MONSTER_H

#include <iostream>
#include <string>

#include "Spell.h"
#include "Behavior.h"
#include "Text.h"

class Monster
{
	protected:
		void newMonster (string monster);
		void createSpell(string name, int cost);
		void addBehavior(bool attack);
		void addText(string text);
};
#endif
