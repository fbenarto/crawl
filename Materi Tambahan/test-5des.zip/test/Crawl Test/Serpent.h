#include "Monster.h"


class Serpent : protected Monster
{
	protected:
		void add()
		{
			Monster::newMonster("Serpent");
			Monster::createSpell("Poison",5);
			Monster::addBehavior(true);
			Monster::addText("A snake-like monster that spews poison");
		}
};

