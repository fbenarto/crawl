#ifndef TEXT_H
#define TEXT_H

#include <iostream>
#include <string>
using namespace std;

class Text
{
	protected:
		string description;
};
#endif