#include "Behavior.h"

void isAggressive(bool attack)
{
	/*Behavior.canAttack = attack;*/
	if(attack)
	{
        cout << "Monster is aggressive" << endl;
    }
    else
    {
        cout << "Monster is not aggressive" << endl;
    }
}
