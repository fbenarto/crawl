#include <iostream>
#include <string>

#include "Monster.h"

class Behavior : protected Monster
{
    protected:
        void behavior_Dragon()
        {
            Monster::addBehavior(true);
        }
        void behavior_Serpent()
        {
            Monster::addBehavior(true);
        }
        void behavior_Ghost()
        {
            Monster::addBehavior(false);
        }
};

