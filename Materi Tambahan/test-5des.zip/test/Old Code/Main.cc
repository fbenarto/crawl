#include "Spell.h"
#include "Behavior.h"
#include "Text.h"
#include "Monster.h"

class Print : protected Spell, protected Behavior, protected Text, protected Monster
{
    public:
        void create()
        {
            //Monster::newMonster("Dragon");
            Spell::spell_Dragon();
            Behavior::behavior_Dragon();
            Text::text_Dragon();

            //Monster::newMonster("Serpent");
            Spell::spell_Serpent();
            Behavior::behavior_Serpent();
            Text::text_Serpent();

            //Monster::newMonster("Ghost");
            Spell::spell_Ghost();
            Behavior::behavior_Ghost();
            Text::text_Ghost();
        }
};

int main()
{
    Print print;
    print.create();
    return 0;
}

