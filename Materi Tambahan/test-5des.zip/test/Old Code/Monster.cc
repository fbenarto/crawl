#include "Monster.h"

void Monster::newMonster(string monster)
{
    cout << monster << endl;
}
void Monster::createSpell(string name, int cost)
{
	/*Spell.spellName = name;
	Spell.spellCost = cost;*/
	cout << "Spell: "<< name << endl;
	cout << "Spell cost: " << cost << endl;
}
void Monster::addBehavior(bool attack)
{
	/*Behavior.canAttack = attack;*/
	if(attack)
	{
        cout << "Monster is aggressive" << endl;
    }
    else
    {
        cout << "Monster is not aggressive" << endl;
    }
}
void Monster::addText(string text)
{
	/*Text.description = text;*/
	cout << text << endl << endl;
}
