#include "Spell.h""

void spellName(string name)
{
    cout << "Spell: "<< name << endl;
}

void spellCost(int cost)
{
    cout << "Spell cost: " << cost << endl;
}
