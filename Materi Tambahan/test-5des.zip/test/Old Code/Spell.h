#include <iostream>
#include <string>

#include "Monster.h"

class Spell : protected Monster
{
    protected:
        void spell_Dragon()
        {
            Monster::createSpell("Fire",10);
        }
        void spell_Serpent()
        {
            Monster::createSpell("Poison",5);
        }
        void spell_Ghost()
        {
            Monster::createSpell("Curse",20);
        }
};
