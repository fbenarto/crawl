#include "Text.h"

void descriptionText(string desc)
{
	/*Text.description = text;*/
	cout << desc << endl << endl;
}

