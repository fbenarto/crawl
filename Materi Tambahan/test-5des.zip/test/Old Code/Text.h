#include <iostream>
#include <string>

#include "Monster.h"

class Text : protected Monster
{
    protected:
        void text_Dragon()
        {
            Monster::addText("A flying monster that breathes fire");
        }
        void text_Serpent()
        {
            Monster::addText("A snake-like monster that spews poison");
        }
        void text_Ghost()
        {
            Monster::addText("An astral creature wandering around");
        }
};


