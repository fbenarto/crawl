#include "Monster.h"


class Dragon : protected Monster
{
	public:
		void add_Dragon()
		{
			Monster::createSpell("fire",10);
			Monster::addBehavior(true);
			Monster::addText("Breath of Fire");
		}
};

int main()
{
	Dragon dragon;
	dragon.add_Dragon();
	return 0;
}