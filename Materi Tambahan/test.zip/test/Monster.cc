#include "Monster.h"

void Monster::createSpell(string name, int cost)
{
	/*Spell.spellName = name;
	Spell.spellCost = cost;*/
	cout << name;
	cout << cost;
}
void Monster::addBehavior(bool attack)
{
	/*Behavior.canAttack = attack;*/
	cout << attack;
}
void Monster::addText(string text)
{
	/*Text.description = text;*/
	cout << text;
}