#ifndef MONSTER_H
#define MONSTER_H

#include "Spell.h"
#include "Behavior.h"
#include "Text.h"

class Monster : protected Spell, protected Behavior, protected Text
{
	protected:
		void createSpell(string name, int cost);
		void addBehavior(bool attack);
		void addText(string text);
};
#endif