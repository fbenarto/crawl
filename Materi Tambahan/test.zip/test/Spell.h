#ifndef SPELL_H
#define SPELL_H

#include <iostream>
#include <string>
using namespace std;

class Spell
{
	protected:
		string spellName;
		int spellCost;
};
#endif